import EcommerceDashboard from '../../apps/ecommerce/dashboard/page'

const DashboardECommerce = () => {
  return <EcommerceDashboard />
}

export default DashboardECommerce
