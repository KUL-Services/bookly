import LogisticsDashboard from '../../apps/logistics/dashboard/page'

const DashboardLogistics = () => {
  return <LogisticsDashboard />
}

export default DashboardLogistics
