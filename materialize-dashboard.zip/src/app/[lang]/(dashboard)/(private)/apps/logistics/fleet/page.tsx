// Component Imports
import Fleet from '@views/apps/logistics/fleet'

const FleetPage = () => {
  return <Fleet />
}

export default FleetPage
